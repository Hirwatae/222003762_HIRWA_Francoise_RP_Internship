// ✅ FULLY UPDATED SERVER USING MYSQL (Combined Learner and Admin Code)

const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bcrypt = require('bcrypt'); // For password hashing
const jwt = require('jsonwebtoken'); // For JWT token generation and verification
const nodemailer = require('nodemailer'); // For sending emails

const app = express();

// CORS Configuration
const corsOptions = {
    origin: 'http://localhost:3000', // IMPORTANT: Adjust this to your frontend's actual origin in production
    credentials: true,
    optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

app.use(express.json()); // Middleware to parse JSON request bodies

// JWT Secret Key - IMPORTANT: Change this to a strong, random key in production!
const secretKey = process.env.JWT_SECRET || "your_jwt_secret_really_strong_key_here";

// MySQL database connection configuration
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '', // IMPORTANT: REPLACE WITH YOUR ACTUAL MYSQL PASSWORD if you have one set
    database: 'elearning'
};

const db = mysql.createConnection(dbConfig);

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error('ERROR: Could not connect to MySQL database:', err.stack);
        return;
    }
    console.log('SUCCESS: Connected to MySQL database as id ' + db.threadId);
});

// --- Nodemailer Transporter Setup ---
// !!! CRITICAL: This section is the MOST COMMON reason emails don't send !!!
// You MUST replace 'your_email@example.com' and 'your_email_password' with your actual
// email address and its corresponding password or, for services like Gmail, an App Password.
// For Gmail, enable 2FA and generate an App Password.
const transporter = nodemailer.createTransport({
    service: 'gmail', // Example: 'gmail'. You can also use 'outlook', 'sendgrid', 'smtp' (with host/port)
    auth: {
        user: 'your_email@example.com', // <-- REPLACE THIS with your actual sending email
        pass: 'your_email_password',     // <-- REPLACE THIS with your actual password or App Password
    },
});

// --- Helper function to send emails ---
const sendEmail = async (toEmail, subject, htmlContent) => {
    // Basic check to prevent sending if credentials are still default placeholders
    if (!transporter.options.auth.user || transporter.options.auth.user === 'your_email@example.com') {
        console.error('ERROR: Nodemailer transporter not configured. Please set up your email credentials in server.js.');
        return; // Prevent email sending if not configured
    }

    try {
        const info = await transporter.sendMail({
            from: '"E-Learning Platform" <your_email@example.com>', // Sender address, REPLACE THIS with your email
            to: toEmail, // Recipient address
            subject: subject, // Subject line
            html: htmlContent, // HTML body
        });
        console.log(`Email sent successfully to ${toEmail} for subject: "${subject}". Message ID: ${info.messageId}`);
    } catch (error) {
        console.error(`ERROR: Failed to send email to ${toEmail} with subject "${subject}":`, error);
        console.error('Nodemailer error details:', error.response); // Log more details from Nodemailer
        console.error('--- COMMON EMAIL SENDING ISSUES & FIXES ---');
        console.error('1. Incorrect "user" or "pass" in Nodemailer config.');
        console.error('2. For Gmail: Did you use an "App Password" if 2FA is ON?');
        console.error('3. For Gmail: Is "Less secure app access" enabled if 2FA is OFF?');
        console.error('4. Network firewall blocking outgoing SMTP (ports 465/587).');
        console.error('5. Recipient email address might be invalid or rejecting emails.');
    }
};

// Middleware to verify JWT token and check admin role
const authenticateAdmin = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: "Access Denied: No token provided." });
    }

    try {
        const verified = jwt.verify(token, secretKey);
        req.user = verified; // { id, username, role }

        if (req.user.role !== 'admin') {
            return res.status(403).json({ error: "Access Denied: Not an administrator." });
        }
        next();
    } catch (err) {
        if (err.name === 'TokenExpiredError') {
            return res.status(401).json({ error: "Access Denied: Token expired." });
        }
        return res.status(400).json({ error: "Invalid Token." });
    }
};

// =================================================================
//          ✅ AUTHENTICATION ROUTES (Learner & Admin) ✅
// =================================================================

// User Registration
app.post("/registration", async (req, res) => {
    const { firstname, lastname, username, email, password, role } = req.body;

    if (!firstname || !lastname || !username || !email || !password || !role) {
        console.error('ERROR: Registration - Missing required fields.');
        return res.status(400).json({ error: "ERROR: All fields are required for registration." });
    }

    try {
        const checkUserSql = 'SELECT * FROM registration WHERE username = ? OR email = ?';
        db.query(checkUserSql, [username, email], async (checkErr, checkResults) => {
            if (checkErr) {
                console.error('ERROR: Database error checking existing user during registration:', checkErr.stack);
                return res.status(500).json({ error: 'ERROR: Database error during registration.' });
            }

            if (checkResults.length > 0) {
                console.warn('WARNING: Registration attempt with existing username or email:', username, email);
                return res.status(409).json({ error: 'ERROR: Username or email already exists.' });
            }

            const hashedPassword = await bcrypt.hash(password, 10);
            // Default status to 'active' for new registrations
            const insertSql = 'INSERT INTO registration (firstname, lastname, username, email, password, role, status) VALUES (?, ?, ?, ?, ?, ?, "active")';
            db.query(insertSql, [firstname, lastname, username, email, hashedPassword, role], (insertErr, insertResult) => {
                if (insertErr) {
                    console.error('ERROR: Database error registering user:', insertErr.stack);
                    return res.status(500).json({ error: 'ERROR: Database error during registration.' });
                }
                console.log('SUCCESS: User registered successfully:', insertResult.insertId);
                return res.status(201).json({ message: 'SUCCESS: Registration successful!', userId: insertResult.insertId });
            });
        });
    } catch (error) {
        console.error('ERROR: Uncaught error during registration process:', error.stack);
        return res.status(500).json({ error: 'ERROR: Internal server error during registration.' });
    }
});

// User Login
app.post("/login", async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        console.error('ERROR: Login - Username and password are required.');
        return res.status(400).json({ error: 'ERROR: Username and password are required.' });
    }

    const sql = 'SELECT id, username, password, role, status, email FROM registration WHERE username = ?';
    db.query(sql, [username], async (err, results) => {
        if (err) {
            console.error('ERROR: Database error during login query:', err.stack);
            return res.status(500).json({ error: 'ERROR: Database error during login.' });
        }

        if (results.length === 0) {
            console.warn('WARNING: Login attempt with non-existent username:', username);
            return res.status(401).json({ error: 'ERROR: Invalid credentials.' });
        }

        const user = results[0];
        if (user.status === 'disabled') {
            console.warn('WARNING: Login attempt for disabled account:', username);
            return res.status(403).json({ error: 'ERROR: Your account has been disabled. Please contact support.' });
        }

        try {
            const passwordMatch = await bcrypt.compare(password, user.password);

            if (passwordMatch) {
                // Generate JWT token
                const token = jwt.sign(
                    { id: user.id, username: user.username, role: user.role },
                    secretKey,
                    { expiresIn: "1h" } // Token expires in 1 hour
                );

                console.log('SUCCESS: User logged in:', user.username, 'Role:', user.role);
                return res.status(200).json({
                    message: 'SUCCESS: Login successful!',
                    token: token, // Return the JWT token
                    role: user.role,
                    username: user.username,
                    userId: user.id,
                    email: user.email
                });
            } else {
                console.warn('WARNING: Login attempt with incorrect password for user:', username);
                return res.status(401).json({ error: 'ERROR: Invalid credentials.' });
            }
        } catch (bcryptError) {
            console.error('ERROR: Error comparing passwords during login:', bcryptError.stack);
            return res.status(500).json({ error: 'ERROR: Internal server error during login.' });
        }
    });
});

// Password Reset (Placeholder for token generation and verification logic)
app.post("/reset-password", (req, res) => {
    const { email } = req.body;

    if (!email) {
        console.error('ERROR: Password Reset - Email is required.');
        return res.status(400).json({ error: 'ERROR: Email is required for password reset.' });
    }

    const sql = 'SELECT id, email, firstname, username FROM registration WHERE email = ?';
    db.query(sql, [email], (err, results) => {
        if (err) {
            console.error('ERROR: Database error during password reset request:', err.stack);
            return res.status(500).json({ error: 'ERROR: Database error during password reset.' });
        }

        if (results.length === 0) {
            console.warn('WARNING: Password Reset attempt for non-existent email:', email);
            // Still return a success message to prevent user enumeration
            return res.status(200).json({ message: 'If an account with that email exists, a password reset link has been sent.' });
        }

        const user = results[0];
        console.log('INFO: Password reset requested for:', user.email);

        // In a real application, you would generate a unique, time-limited token here
        // and store it in your database associated with the user.
        // Then, the URL would contain this token:
        // const resetToken = crypto.randomBytes(32).toString('hex'); // Requires 'crypto' module
        // const resetLink = `YOUR_FRONTEND_RESET_PAGE_URL_HERE?token=${resetToken}&email=${encodeURIComponent(user.email)}`;

        const resetHtml = `
            <p>Dear ${user.firstname || user.username || 'User'},</p>
            <p>You recently requested a password reset for your E-Learning Platform account.</p>
            <p>Please click on the following link to reset your password: <a href='YOUR_FRONTEND_RESET_PAGE_URL_HERE?token=YOUR_RESET_TOKEN'>Reset Password</a></p>
            <p>If you did not request a password reset, please ignore this email.</p>
            <p>Best regards,<br>The E-Learning Platform Team</p>
        `;
        sendEmail(user.email, "E-Learning Platform: Password Reset Request", resetHtml);
        return res.status(200).json({ message: 'If an account with that email exists, a password reset link has been sent.' });
    });
});


// =================================================================
//           ✅ LEARNER-SPECIFIC ROUTES ✅
// =================================================================

// GET Learner Profile by User ID
app.get('/users/:userId', (req, res) => {
    const userId = parseInt(req.params.userId);
    const sql = 'SELECT id, firstname, lastname, username, email, role, status FROM registration WHERE id = ?';
    db.query(sql, [userId], (err, results) => {
        if (err) {
            console.error("Error fetching learner profile:", err.stack);
            return res.status(500).json({ error: "Failed to fetch learner profile." });
        }
        if (results.length === 0) {
            return res.status(404).json({ error: 'User not found.' });
        }
        const user = results[0];
        res.json({
            id: user.id,
            firstname: user.firstname,
            lastname: user.lastname,
            username: user.username,
            email: user.email,
            role: user.role,
            status: user.status
        });
    });
});

// GET All Published Modules (Courses) for Learners
app.get('/courses', (req, res) => {
    // FIX: Removed 'credits' from the SELECT statement as it caused ER_BAD_FIELD_ERROR
    // This assumes the 'credits' column does not exist in your 'modules' table.
    // If it should exist, you need to add it to your database schema.
    const sql = `SELECT id, title, description, lecturer_id, pages FROM modules WHERE is_published = TRUE`;
    db.query(sql, (err, rows) => {
        if (err) {
            console.error('ERROR: Error fetching modules for learners:', err.stack);
            return res.status(500).json({ error: 'ERROR: Failed to load courses from the database.' });
        }
        res.json(rows);
    });
});

// GET Module Notes by Module ID and Page Number
app.get('/courses/:moduleId/notes/:pageNumber', (req, res) => {
    const moduleId = parseInt(req.params.moduleId);
    const pageNumber = parseInt(req.params.pageNumber);

    const getNoteSql = `SELECT content FROM notes WHERE module_id = ? AND page_number = ?`;
    db.query(getNoteSql, [moduleId, pageNumber], (err, noteResults) => {
        if (err) {
            console.error('ERROR: Error fetching notes:', err.stack);
            return res.status(500).json({ error: 'ERROR: Failed to load module notes.' });
        }
        if (noteResults.length === 0) {
            return res.status(404).json({ error: 'ERROR: Note page not found for this module.' });
        }

        // Fetch total pages from the modules table for pagination info
        const getTotalPagesSql = `SELECT pages FROM modules WHERE id = ?`;
        db.query(getTotalPagesSql, [moduleId], (err, moduleResults) => {
            const totalPages = moduleResults.length > 0 ? moduleResults[0].pages : 0;
            res.json({
                content: noteResults[0].content,
                pageNumber: pageNumber,
                totalPages: totalPages
            });
        });
    });
});

// GET Assessment Questions by Module ID
app.get('/assessments/:moduleId', (req, res) => {
    const moduleId = parseInt(req.params.moduleId);
    const sql = `SELECT id, question, options, answer FROM assessments WHERE module_id = ?`;
    db.query(sql, [moduleId], (err, questions) => {
        if (err) {
            console.error('ERROR: Error fetching questions:', err.stack);
            return res.status(500).json({ error: 'ERROR: Failed to fetch assessment questions.' });
        }
        res.json(questions);
    });
});

// POST: Enroll a learner in a module
app.post('/enrollments', (req, res) => {
    const { userId, moduleId } = req.body;

    if (!userId || !moduleId) {
        console.error('ERROR: Enrollment - User ID and Module ID are required.');
        return res.status(400).json({ error: 'ERROR: User ID and Module ID are required for enrollment.' });
    }

    const checkEnrollmentSql = 'SELECT id FROM enrollments WHERE user_id = ? AND module_id = ?';
    db.query(checkEnrollmentSql, [userId, moduleId], (checkErr, checkResults) => {
        if (checkErr) {
            console.error('ERROR: Database error checking existing enrollment:', checkErr.stack);
            return res.status(500).json({ error: 'ERROR: Database error during enrollment.' });
        }

        if (checkResults.length > 0) {
            console.warn(`WARNING: Enrollment attempt for existing enrollment (User ID: ${userId}, Module ID: ${moduleId}).`);
            return res.status(409).json({ message: 'User is already enrolled in this module.' });
        }

        const insertEnrollmentSql = 'INSERT INTO enrollments (user_id, module_id, enrollment_date, completion_status) VALUES (?, ?, ?, ?)';
        const enrollmentDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
        db.query(insertEnrollmentSql, [userId, moduleId, enrollmentDate, 'in_progress'], (insertErr, insertResult) => {
            if (insertErr) {
                console.error('ERROR: Database error inserting new enrollment:', insertErr.stack);
                return res.status(500).json({ error: 'ERROR: Failed to enroll in module.', details: insertErr.message });
            }

            const userModuleDetailsSql = `
                SELECT
                    r.email,
                    r.firstname,
                    r.lastname,
                    m.title AS module_title
                FROM registration r
                JOIN modules m ON m.id = ?
                WHERE r.id = ?;
            `;
            db.query(userModuleDetailsSql, [moduleId, userId], (detailsErr, detailsResults) => {
                if (detailsErr) {
                    console.error('ERROR: Database error fetching user/module details for enrollment email:', detailsErr.stack);
                } else if (detailsResults.length > 0 && detailsResults[0].email) {
                    const userDetails = detailsResults[0];
                    const emailSubject = `Welcome to Your New Course: ${userDetails.module_title}!`;
                    const emailHtml = `
                        <p>Dear ${userDetails.firstname || userDetails.username || 'Learner'},</p>
                        <p>Welcome to your new course, <strong>${userDetails.module_title}</strong>!</p>
                        <p>You have successfully enrolled and can now start learning. We hope you enjoy the material!</p>
                        <p>Best regards,<br>The E-Learning Platform Team</p>
                    `;
                    sendEmail(userDetails.email, emailSubject, emailHtml);
                } else {
                    console.warn(`WARNING: Could not send enrollment email. User details or email not found for User ID: ${userId}`);
                }
            });

            // Update enrollment count in modules table
            const updateModuleCountSql = 'UPDATE modules SET enrollment_count = enrollment_count + 1 WHERE id = ?';
            db.query(updateModuleCountSql, [moduleId], (updateErr) => {
                if (updateErr) {
                    console.error('ERROR: Failed to update enrollment count in modules table:', updateErr.stack);
                }
            });

            console.log('SUCCESS: Learner enrolled successfully. Enrollment ID:', insertResult.insertId);
            res.status(201).json({ message: 'Enrollment successful!', enrollmentId: insertResult.insertId });
        });
    });
});

// GET Enrollment Status and Progress
app.get('/enrollments/status', (req, res) => {
    const { userId, moduleId } = req.query;
    const sql = `SELECT * FROM enrollments WHERE user_id = ? AND module_id = ?`;
    db.query(sql, [userId, moduleId], (err, rows) => {
        if (err) {
            console.error("Error fetching enrollment status:", err.stack);
            return res.status(500).json({ error: "Failed to fetch enrollment status." });
        }
        if (rows.length === 0) {
            return res.json({ isEnrolled: false });
        }
        const row = rows[0];
        res.json({
            isEnrolled: true,
            enrollmentDate: row.enrollment_date,
            completionStatus: row.completion_status,
            score: row.score,
            completionDate: row.completion_date,
            lastViewedPage: row.last_viewed_page,
            courseProgress: row.course_progress
        });
    });
});

// PUT: Update Module Progress (last viewed page and percentage)
app.put('/enrollments/update-progress', (req, res) => {
    const { userId, moduleId, lastViewedPage, courseProgress } = req.body;
    const sql = `UPDATE enrollments SET last_viewed_page = ?, course_progress = ? WHERE user_id = ? AND module_id = ?`;
    db.query(sql, [lastViewedPage, courseProgress, userId, moduleId], (err, result) => {
        if (err) {
            console.error("Error updating progress:", err.stack);
            return res.status(500).json({ error: "Failed to update progress." });
        }
        if (result.affectedRows > 0) {
            res.json({ message: 'Progress updated successfully.' });
        } else {
            res.status(404).json({ message: 'Enrollment not found or no changes made.' });
        }
    });
});


// PUT: Update enrollment completion status with Email Notification
app.put('/enrollments/complete', (req, res) => {
    const { userId, moduleId, completionStatus, score, completionDate } = req.body;

    if (!userId || !moduleId || !completionStatus || score === undefined || !completionDate) {
        console.error('ERROR: Update Enrollment Completion - Missing required fields.');
        return res.status(400).json({ error: 'ERROR: Missing required fields for updating completion status.' });
    }

    if (!['completed', 'failed', 'in_progress'].includes(completionStatus)) {
        console.error('ERROR: Update Enrollment Completion - Invalid completion status:', completionStatus);
        return res.status(400).json({ error: 'ERROR: Invalid completion status provided.' });
    }

    const updateSql = 'UPDATE enrollments SET completion_status = ?, score = ?, completion_date = ? WHERE user_id = ? AND module_id = ?';
    const formattedCompletionDate = new Date(completionDate).toISOString().slice(0, 19).replace('T', ' ');

    db.query(updateSql, [completionStatus, score, formattedCompletionDate, userId, moduleId], (err, result) => {
        if (err) {
            console.error('ERROR: Database error updating enrollment completion status:', err.stack);
            return res.status(500).json({ error: 'ERROR: Failed to update enrollment completion status.', details: err.message });
        }

        if (result.affectedRows === 0) {
            console.warn(`WARNING: Attempt to update non-existent enrollment (User ID: ${userId}, Module ID: ${moduleId}).`);
            return res.status(404).json({ message: 'ERROR: Enrollment record not found for update.' });
        }

        if (completionStatus === 'completed') {
            const userModuleDetailsSql = `
                SELECT
                    r.email,
                    r.firstname,
                    r.lastname,
                    m.title AS module_title
                FROM registration r
                JOIN modules m ON m.id = ?
                WHERE r.id = ?;
            `;
            db.query(userModuleDetailsSql, [moduleId, userId], (detailsErr, detailsResults) => {
                if (detailsErr) {
                    console.error('ERROR: Database error fetching user/module details for completion email:', detailsErr.stack);
                } else if (detailsResults.length > 0 && detailsResults[0].email) {
                    const userDetails = detailsResults[0];
                    const emailSubject = `Course Completion & Certificate: ${userDetails.module_title}!`;
                    const emailHtml = `
                        <p>Dear ${userDetails.firstname || userDetails.username || 'Learner'},</p>
                        <p>Congratulations! You have successfully completed the course: <strong>${userDetails.module_title}</strong> with a score of ${score.toFixed(2)}%!</p>
                        <p>We are thrilled to see your progress.</p>
                        <p>You can now download your certificate directly from your Learner Dashboard.</p>
                        <p>Keep up the great work!</p>
                        <p>Best regards,<br>The E-Learning Platform Team</p>
                    `;
                    sendEmail(userDetails.email, emailSubject, emailHtml);
                } else {
                    console.warn(`WARNING: Could not send completion email. User details or email not found for User ID: ${userId}`);
                }
            });
        }

        console.log('SUCCESS: Enrollment completion status updated for User ID:', userId, 'Module ID:', moduleId);
        res.status(200).json({ message: 'SUCCESS: Enrollment completion status updated successfully!' });
    });
});


// =================================================================
//           ✅ ADMIN-SPECIFIC ROUTES ✅
// =================================================================

// Get all modules
app.get("/admin/modules", authenticateAdmin, (req, res) => {
    const sql = `
        SELECT m.*, COUNT(e.id) AS enrollment_count
        FROM modules m
        LEFT JOIN enrollments e ON m.id = e.module_id
        GROUP BY m.id
    `;
    db.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching modules:", err.stack);
            return res.status(500).json({ error: "Failed to retrieve modules from database." });
        }
        res.json(results);
    });
});

// Add a new module
app.post("/admin/modules", authenticateAdmin, (req, res) => {
    const { title, description, credits, lecturer_id, pages, is_published } = req.body;

    if (!title || !credits || !lecturer_id || pages === undefined) {
        return res.status(400).json({ error: "Required fields missing for new module." });
    }

    // Basic validation for lecturer_id: check if it exists and is a lecturer
    const checkLecturerSql = "SELECT id FROM registration WHERE id = ? AND role = 'lecturer'";
    db.query(checkLecturerSql, [lecturer_id], (err, lecturerResults) => {
        if (err) {
            console.error("Error checking lecturer:", err.stack);
            return res.status(500).json({ error: "Database error during lecturer check." });
        }
        if (lecturerResults.length === 0) {
            return res.status(400).json({ error: "Lecturer ID does not exist or is not a lecturer." });
        }

        const sql = "INSERT INTO modules (title, description, credits, lecturer_id, pages, is_published) VALUES (?, ?, ?, ?, ?, ?)";
        const values = [title, description, credits, lecturer_id, pages, is_published];

        db.query(sql, values, (err, result) => {
            if (err) {
                console.error("Error adding module:", err.stack);
                return res.status(500).json({ error: "Failed to add module to database." });
            }
            res.status(201).json({ message: "Module added successfully", moduleId: result.insertId });
        });
    });
});

// Update an existing module
app.put("/admin/modules/:id", authenticateAdmin, (req, res) => {
    const { id } = req.params;
    const { title, description, credits, lecturer_id, pages, is_published } = req.body;

    if (!title || !credits || !lecturer_id || pages === undefined) {
        return res.status(400).json({ error: "Required fields missing for module update." });
    }

    // Basic validation for lecturer_id: check if it exists and is a lecturer
    const checkLecturerSql = "SELECT id FROM registration WHERE id = ? AND role = 'lecturer'";
    db.query(checkLecturerSql, [lecturer_id], (err, lecturerResults) => {
        if (err) {
            console.error("Error checking lecturer for update:", err.stack);
            return res.status(500).json({ error: "Database error during lecturer check." });
        }
        if (lecturerResults.length === 0) {
            return res.status(400).json({ error: "Lecturer ID does not exist or is not a lecturer." });
        }

        const sql = "UPDATE modules SET title = ?, description = ?, credits = ?, lecturer_id = ?, pages = ?, is_published = ? WHERE id = ?";
        const values = [title, description, credits, lecturer_id, pages, is_published, id];

        db.query(sql, values, (err, result) => {
            if (err) {
                console.error("Error updating module:", err.stack);
                return res.status(500).json({ error: "Failed to update module in database." });
            }
            if (result.affectedRows === 0) {
                return res.status(404).json({ error: "Module not found." });
            }
            res.json({ message: "Module updated successfully" });
        });
    });
});

// Delete a module (and related enrollments, notes, assessments)
app.delete("/admin/modules/:id", authenticateAdmin, (req, res) => {
    const { id } = req.params;

    // Use a transaction to ensure atomicity
    db.beginTransaction(err => {
        if (err) {
            console.error("Error starting transaction:", err.stack);
            return res.status(500).json({ error: "Database error during transaction start." });
        }

        // 1. Delete related assessments
        const deleteAssessmentsSql = "DELETE FROM assessments WHERE module_id = ?";
        db.query(deleteAssessmentsSql, [id], (err, assessmentsResult) => {
            if (err) {
                return db.rollback(() => {
                    console.error("Error deleting assessments:", err.stack);
                    res.status(500).json({ error: "Failed to delete related assessments." });
                });
            }

            // 2. Delete related notes
            const deleteNotesSql = "DELETE FROM notes WHERE module_id = ?";
            db.query(deleteNotesSql, [id], (err, notesResult) => {
                if (err) {
                    return db.rollback(() => {
                        console.error("Error deleting notes:", err.stack);
                        res.status(500).json({ error: "Failed to delete related notes." });
                    });
                }

                // 3. Delete related enrollments
                const deleteEnrollmentsSql = "DELETE FROM enrollments WHERE module_id = ?";
                db.query(deleteEnrollmentsSql, [id], (err, enrollmentsResult) => {
                    if (err) {
                        return db.rollback(() => {
                            console.error("Error deleting enrollments:", err.stack);
                            res.status(500).json({ error: "Failed to delete related enrollments." });
                        });
                    }

                    // 4. Then delete the module
                    const deleteModuleSql = "DELETE FROM modules WHERE id = ?";
                    db.query(deleteModuleSql, [id], (err, moduleResult) => {
                        if (err) {
                            return db.rollback(() => {
                                console.error("Error deleting module:", err.stack);
                                res.status(500).json({ error: "Failed to delete module from database." });
                            });
                        }

                        if (moduleResult.affectedRows === 0) {
                            return db.rollback(() => {
                                res.status(404).json({ error: "Module not found." });
                            });
                        }

                        db.commit(err => {
                            if (err) {
                                return db.rollback(() => {
                                    console.error("Error committing transaction:", err.stack);
                                    res.status(500).json({ error: "Database error during transaction commit." });
                                });
                            }
                            res.json({
                                message: `Module, ${assessmentsResult.affectedRows} assessments, ${notesResult.affectedRows} notes, and ${enrollmentsResult.affectedRows} enrollments deleted successfully.`
                            });
                        });
                    });
                });
            });
        });
    });
});


// Toggle module publish status
app.put("/admin/modules/:id/publish", authenticateAdmin, (req, res) => {
    const { id } = req.params;
    const { is_published } = req.body; // Expect a boolean value from the request body

    if (typeof is_published !== 'boolean') {
        return res.status(400).json({ error: "Invalid value for 'is_published'. Must be true or false." });
    }

    const sql = "UPDATE modules SET is_published = ? WHERE id = ?";
    db.query(sql, [is_published, id], (err, result) => {
        if (err) {
            console.error("Error updating module publish status:", err.stack);
            return res.status(500).json({ error: "Failed to update module publish status in database." });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Module not found." });
        }
        res.json({ message: `Module publish status updated to ${is_published ? 'published' : 'unpublished'} successfully.` });
    });
});


// Add more admin routes as needed (e.g., managing users, reports)

// 8. Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});